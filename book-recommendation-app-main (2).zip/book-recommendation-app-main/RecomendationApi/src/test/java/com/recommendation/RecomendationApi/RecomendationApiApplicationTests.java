package com.recommendation.RecomendationApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecomendationApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
