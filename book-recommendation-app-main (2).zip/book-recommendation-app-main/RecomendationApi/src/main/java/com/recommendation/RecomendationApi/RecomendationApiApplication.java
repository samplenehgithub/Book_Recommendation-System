package com.recommendation.RecomendationApi;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class RecomendationApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecomendationApiApplication.class, args);
	}

}
