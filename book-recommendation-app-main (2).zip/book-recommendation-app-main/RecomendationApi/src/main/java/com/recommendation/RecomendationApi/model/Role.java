package com.recommendation.RecomendationApi.model;


public enum Role {
	
	ADMIN, USER

}

